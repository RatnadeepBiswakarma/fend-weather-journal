# Weather-Journal App Project

## Overview

# Live URL: https://fend-weather-journal.onrender.com/

![Weather journal app demo image](https://i.imgur.com/Tq7V0QW.png)

Weather journal app for udacity scholarship. It creates new journal entry after fetching weather data from open weather.

## Local Setup

1. Install dependencies by running `yarn install`
2. Run `node server.js` to start a local server
3. visit `http://localhost:3000/` to see the app live
